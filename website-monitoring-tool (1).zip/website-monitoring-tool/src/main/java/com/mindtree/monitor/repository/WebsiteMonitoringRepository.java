package com.mindtree.monitor.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mindtree.monitor.model.Check;
public interface WebsiteMonitoringRepository extends JpaRepository<Check, String>{


	List<Check> findByNameContainingIgnoreCase(String name);
	@Query("Select u from Check u where u.frequency=?1")
	List<Check> findByFrequency(long frequency);
}