package com.mindtree.monitor.service;

import java.util.List;

import com.mindtree.monitor.exception.InvalidCheckException;
import com.mindtree.monitor.model.Check;

public interface WebsiteMonitoringService {
	 void createCheck(Check check) throws InvalidCheckException;
     List<Check> getAllCheck();
     List<Check> filterCheckByIntervalAndName(String check);
     void deactivateCheck(String name);
     void activateCheck(String name);
     void deleteCheck(String name);
     void updateCheck(Check check) throws InvalidCheckException;
}
