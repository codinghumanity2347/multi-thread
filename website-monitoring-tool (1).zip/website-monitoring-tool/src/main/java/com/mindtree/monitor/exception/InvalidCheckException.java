package com.mindtree.monitor.exception;

public class InvalidCheckException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public InvalidCheckException(String message) {
		super(message);
	}
}
