package com.mindtree.monitor.authentication;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mindtree.monitor.dto.LoginDTO;
import com.mindtree.monitor.exception.CustomerNotFoundException;
import com.mindtree.monitor.exception.UnauthorizedException;
import com.mindtree.monitor.model.User;
import com.mindtree.monitor.repository.UserRepository;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JwtAuthenticationService implements UserDetailsService{

	//private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationService.class);
@Autowired
UserRepository repository;
	
	

//	private static final long EXPIRATION_TIME = 1000*60*5;
//
//	public String authenticateUser(LoginDTO user) throws UnauthorizedException {
//		
//		if (!user.getEmail().equals("shreya@gmail.com")) {
//			
//			throw new CustomerNotFoundException("Please check your email or register for a new account");
//		}
//		if (!user.getPassword().equals("password")) {
//			
//			throw new UnauthorizedException("Invalid Credentials");
//
//		}
//		return Jwts.builder().setSubject(user.getEmail()).claim("roles", "user").setIssuedAt(new Date())
//				.signWith(SignatureAlgorithm.HS256, "secretkey")
//				.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME)).compact();
//
//	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	 User user=repository.findByUserName(username);
	 return new org.springframework.security.core.userdetails.User(user.getUserName(),user.getPassword(),new ArrayList<>());
	}

}
