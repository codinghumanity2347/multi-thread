package com.mindtree.monitor.controller;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Stopwatch;
import com.mindtree.monitor.exception.InvalidCheckException;
import com.mindtree.monitor.model.Check;
import com.mindtree.monitor.service.WebsiteMonitoringService;

@RestController
@CrossOrigin(origins = "*") 
public class WebsiteMonitoringController {
@Autowired
WebsiteMonitoringService service;

	@PostMapping(path = "/check")
 public ResponseEntity<String> createCheck(@RequestBody Check check) throws InvalidCheckException {
		service.createCheck(check);
		return ResponseEntity.status(HttpStatus.OK).body("Successfully added new check");
		
		}
	
	@GetMapping(path = "/check")
	 public ResponseEntity<List<Check>> getAllCheck() {
			 List<Check> checkList=service.getAllCheck();
			return ResponseEntity.status(HttpStatus.OK).body(checkList);
			
			}
	
	@GetMapping(path = "/check/filter")
	 public ResponseEntity<List<Check>> filterCheckByIntervalAndName(@RequestParam("check") String check) {
			List<Check> filterCheckList=service.filterCheckByIntervalAndName(check);
			return ResponseEntity.status(HttpStatus.OK).body(filterCheckList);
			
			}
	@GetMapping(path = "/check/deactivate")
	 public ResponseEntity<?> deactivateCheck(@RequestParam("name") String name) {
			service.deactivateCheck(name);
			return ResponseEntity.status(HttpStatus.OK).body("Successfully check is deactivated");
			
			}
	@GetMapping(path="/check/activate")
	 public ResponseEntity<?> activateCheck(@RequestParam("name") String name) {
			service.activateCheck(name);
			return ResponseEntity.status(HttpStatus.OK).body("Successfully check is activated");
			
			}

	@DeleteMapping(path="/check/delete")
	 public ResponseEntity<String> deleteCheck(@RequestParam("name") String name) {
		service.deleteCheck(name);
			return ResponseEntity.status(HttpStatus.OK).body("Successfully deleted");
			
			}
	@PostMapping(path="/check/update")
	public ResponseEntity<String> updateCheck(@RequestBody Check check) throws InvalidCheckException {
		service.updateCheck(check);
			return ResponseEntity.status(HttpStatus.OK).body("Successfully updated");
			
			}
}
