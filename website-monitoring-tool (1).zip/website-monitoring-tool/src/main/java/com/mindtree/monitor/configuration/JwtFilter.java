package com.mindtree.monitor.configuration;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindtree.monitor.authentication.JwtAuthenticationService;
import com.mindtree.monitor.exception.CustomGlobalExceptionHandler;
import com.mindtree.monitor.exception.InvalidTokenException;
import com.mindtree.monitor.service.JwtUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;


@Configuration
public class JwtFilter extends OncePerRequestFilter {

//	CustomGlobalExceptionHandler handler = new CustomGlobalExceptionHandler();
//
//	
//
//	public String convertObjectToJson(Object object) throws JsonProcessingException {
//		if (object == null) {
//			return null;
//		}
//		ObjectMapper mapper = new ObjectMapper();
//		return mapper.writeValueAsString(object);
//	}
//
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
//			throws ServletException, IOException {
//		final String authHeader = request.getHeader("authorization");
//		if ("OPTIONS".equals(request.getMethod())) {
//			response.setStatus(HttpServletResponse.SC_OK);
//
//			filterChain.doFilter(request, response);
//		} else {
//
//			try {
//
//				if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//
//					throw new InvalidTokenException("Missing or invalid Authorization header");
//				}
//
//				final String token = authHeader.substring(7);
//				final Claims claims = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody();
//				
//				request.setAttribute("claims", claims);
//			} catch (ExpiredJwtException e) {
//				ResponseEntity<?> errorDTO = handler.exception(e);
//
//				// set the response object
//				response.setStatus(errorDTO.getStatusCodeValue());
//				response.setContentType("application/json");
//
//				// pass down the actual obj that exception handler normally send
//				ObjectMapper mapper = new ObjectMapper();
//				PrintWriter out = response.getWriter();
//				out.print(mapper.writeValueAsString(errorDTO));
//				out.flush();
//
//				return;
//
//			} catch (InvalidTokenException e) {
//
//				ResponseEntity<?> errorDTO = handler.exception(e);
//
//				// set the response object
//				response.setStatus(errorDTO.getStatusCodeValue());
//				response.setContentType("application/json");
//
//				// pass down the actual obj that exception handler normally send
//				ObjectMapper mapper = new ObjectMapper();
//				PrintWriter out = response.getWriter();
//				out.print(mapper.writeValueAsString(errorDTO));
//				out.flush();
//
//				return;
//
//			}
//
//			filterChain.doFilter(request, response);
//		}
//
//		
//	}
	
	
	@Autowired
	private JwtUtil jwtUtill;
	
	@Autowired
	private JwtAuthenticationService service;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		//Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ4YWRtaW4iLCJleHAiOjE1OTUxODMyMTcsImlhdCI6MTU5NTE0NzIxN30.S9w8LROFAKYCWU2nsHu07FcWGfI5vwesC4MvsqzGDyo
		String autherizationHeader = request.getHeader("Authorization");
		String token = null;
		String username=null;
		if(autherizationHeader !=null && autherizationHeader.startsWith("Bearer"))
		{
			token = autherizationHeader.substring(7);
			username = jwtUtill.extractUsername(token);
		}
			if(username !=null && SecurityContextHolder.getContext().getAuthentication() == null)
			{
				UserDetails userDetails = service.loadUserByUsername(username);
				
				if (jwtUtill.validateToken(token, userDetails)) {

					UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
							userDetails, null, userDetails.getAuthorities());
					usernamePasswordAuthenticationToken
							.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
					SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
				}
			}
			filterChain.doFilter(request, response);
			}
}
