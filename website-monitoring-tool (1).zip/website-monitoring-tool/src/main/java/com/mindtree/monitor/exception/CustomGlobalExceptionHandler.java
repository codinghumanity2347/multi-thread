package com.mindtree.monitor.exception;

import javax.servlet.ServletException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import io.jsonwebtoken.ExpiredJwtException;



@ControllerAdvice
public class CustomGlobalExceptionHandler extends ResponseEntityExceptionHandler{
	
	//private static final Logger logger = LoggerFactory.getLogger(CustomGlobalExceptionHandler.class);

	@ExceptionHandler(InvalidTokenException.class)
	public
	ResponseEntity<Object> exception(InvalidTokenException exception) {
		return new ResponseEntity<Object>(exception.getMessage(), HttpStatus.FORBIDDEN);
	}
	@ExceptionHandler(InvalidCheckException.class)
	public
	ResponseEntity<Object> exception(InvalidCheckException exception) {
		return new ResponseEntity<Object>(exception.getMessage(), HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler(ExpiredJwtException.class)
	public
	ResponseEntity<Object> exception(ExpiredJwtException exception) {

		return new ResponseEntity<>(exception.getMessage(), HttpStatus.FORBIDDEN);
	}

	@ExceptionHandler(CustomerNotFoundException.class)
	ResponseEntity<Object> exception(CustomerNotFoundException exception) {

		return new ResponseEntity<>(exception.getMessage(), HttpStatus.NOT_FOUND);
	}
	@ExceptionHandler(UnauthorizedException.class)
	ResponseEntity<Object> exception(UnauthorizedException exception) {

		return new ResponseEntity<>(exception.getMessage(), HttpStatus.UNAUTHORIZED);
	}
}