package com.mindtree.monitor;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.mindtree.monitor.configuration.JwtFilter;
import com.mindtree.monitor.model.User;
import com.mindtree.monitor.repository.UserRepository;


@SpringBootApplication
@EnableEurekaClient
public class WebsiteMonitoringToolApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsiteMonitoringToolApplication.class, args);
	}
	
	@Autowired
	private UserRepository repository;
	

	@PostConstruct
	public void initUsers()
	{
		   List<User> users = Stream.of(
	                new User(101, "xadmin", "xadminpassword", "xadmin@gmail.com"),
	                new User(102, "ashish", "ashishpassword", "ashish@gmail.com"),
	                new User(103, "gurpreet", "gurpreetpassword", "gurpreet@gmail.com"),
	                new User(104, "mohit", "mohitpassword", "mohit@gmail.com")
	        ).collect(Collectors.toList());
	        repository.saveAll(users);
	}
//	@Bean
//	public FilterRegistrationBean<JwtFilter> jwtFilter() {
//		final FilterRegistrationBean<JwtFilter> registrationBean = new FilterRegistrationBean<JwtFilter>();
//		registrationBean.setFilter(new JwtFilter());
//		registrationBean.addUrlPatterns("/check/*");
//		return registrationBean;
//	}
//	@Bean
//    public WebMvcConfigurer corsConfigurer() {
//        return new WebMvcConfigurer() {
//            @Override
//            public void addCorsMappings(CorsRegistry registry) {
//                registry.addMapping("/**").allowedOrigins("http://localhost:4200");
//            }
//        };
//    }
}
