package com.mindtree.monitor.controller;

import java.util.Date;

import org.apache.http.auth.UsernamePasswordCredentials;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.monitor.authentication.JwtAuthenticationService;
import com.mindtree.monitor.dto.LoginDTO;
import com.mindtree.monitor.exception.UnauthorizedException;
import com.mindtree.monitor.service.JwtUtil;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


@RestController
@CrossOrigin(origins = "*") 
public class JwtAuthenticationController {

	private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationController.class);

	@Autowired
	AuthenticationManager authenticationManager;
@Autowired
JwtUtil jwtUtil;

	@PostMapping("/login")
	public ResponseEntity<String> enroll(@RequestBody LoginDTO user) throws UnauthorizedException  {
		logger.debug("Calling authentication service to verify user");
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(user.getUserName(), user.getPassword()));
		logger.debug("User verified, returning back token");	
		
		 String token=jwtUtil.generateToken(user.getUserName());
		return ResponseEntity
				.status(HttpStatus.OK)
				.body(token);


	}

}
