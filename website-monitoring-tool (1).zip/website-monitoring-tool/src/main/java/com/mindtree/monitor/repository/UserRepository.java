package com.mindtree.monitor.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.monitor.model.User;


public interface UserRepository extends JpaRepository<User, Integer>{

	User findByUserName(String username);

}