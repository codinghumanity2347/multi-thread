package com.mindtree.monitor.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.security.cert.Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLPeerUnverifiedException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.Trigger;
import org.springframework.scheduling.TriggerContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Service;

import com.google.common.base.Stopwatch;
import com.mindtree.monitor.exception.InvalidCheckException;
import com.mindtree.monitor.model.Check;
import com.mindtree.monitor.repository.WebsiteMonitoringRepository;

@Service
public class WebsiteMonitoringServiceImplementation implements WebsiteMonitoringService {
	@Autowired
	WebsiteMonitoringRepository repository;
 @Autowired
 TaskScheduler taskScheduler;
 private  Map<String, ScheduledFuture<?>> scheduledTasks =
	        new IdentityHashMap<>();
	@Override
	public void createCheck(Check check) throws InvalidCheckException {
		checkStatusAndStoreInDatabase(check);
		createJob(check);

	}
	public void checkStatusAndStoreInDatabase(Check check) throws InvalidCheckException {
		Check checkResponse = statusForSingleCheck(check);
		check.setStatus_check(checkResponse.getStatus_check());
		check.setResponseTime(checkResponse.getResponseTime());
		check.setDate(checkResponse.getDate());
		repository.save(check);
	}

	@Override
	public List<Check> getAllCheck() {
		return repository.findAll();
	}

	@Override
	public List<Check> filterCheckByIntervalAndName(String check) {
		List<Check> checkList = null;
		if (check.matches("[a-zA-Z]*")) {
			checkList = repository.findByNameContainingIgnoreCase(check);
		} else {
			checkList = repository.findByFrequency(Long.parseLong(check));
		}
		return checkList;
	}

	@Override
	public void deactivateCheck(String name) {
		Check check = repository.findById(name).get();
		check.setIsActive("d");
		;
		repository.save(check);

	}

	@Override
	public void activateCheck(String name) {
		Check check = repository.findById(name).get();
		check.setIsActive("a");
		repository.save(check);

	}


	public Check statusForSingleCheck(Check check_data) throws InvalidCheckException {

		if (check_data.getIsActive().equals("a")) {
			int code = 200;
			boolean flag = false;
			try {

				int i = 0;
				while (i < 3) {
					Stopwatch stopwatch = Stopwatch.createStarted();
					HttpURLConnection connection = getConnect(check_data.getUrl());
					 
			            
			       
					code = connection.getResponseCode();
					stopwatch.stop();
					check_data.setDate(new Date());
					
					if (code == 200) {
						check_data.setResponseTime(stopwatch.elapsed(TimeUnit.MILLISECONDS));
						check_data.setStatus_check("UP");
						flag = true;
						break;

					} else {
						check_data.setResponseTime(0);
						flag = false;
						i++;
						check_data.setStatus_check("DOWN");

					}

				}
				if (!flag) {
					check_data.setResponseTime(0);
					System.err.println("Number of 3 consecutive checks fail for " + " " + check_data.getName());
				}
			} catch (Exception e) {
				throw new InvalidCheckException(e.getMessage());
			}
		} else {
			check_data.setStatus_check("-");
			check_data.setResponseTime(0);
		}

		check_data.setName(check_data.getName());
		check_data.setFrequency(check_data.getFrequency());
		check_data.setUrl(check_data.getUrl());
		return check_data;
	}

	public HttpURLConnection getConnect(String url) throws Exception {
		URL siteURL = new URL(url);

		HttpURLConnection connection = (HttpURLConnection) siteURL.openConnection();
		connection.setRequestProperty("User-Agent", "Mozilla/5.0");
		connection.setRequestMethod("GET");
		connection.setConnectTimeout(3000);
		connection.connect();
		return connection;
	}

	@Override
	public void deleteCheck(String name) {
		repository.deleteById(name);
		cancelJob(name);
	}

	@Override
	public void updateCheck(Check check) throws InvalidCheckException {
		Check checkData = repository.findById(check.getName()).get();
		checkData.setFrequency(check.getFrequency());
		checkData.setUrl(check.getUrl());
		checkData.setIsActive(check.getIsActive());
		for (Map.Entry<String, ScheduledFuture<?>> entry : scheduledTasks
				.entrySet()) {
		  if(entry.getKey().equals(check.getName())){
			  entry.getValue().cancel(true);
			  scheduledTasks.remove(entry.getKey());
		break;
		  }
		}
				
		checkData = statusForSingleCheck(checkData);
		
		repository.save(checkData);
		createJob(checkData);

	}
	public void cancelJob(String name) {
		for (Map.Entry<String, ScheduledFuture<?>> entry : scheduledTasks
				.entrySet()) {
		  if(entry.getKey().equals(name)){
			  entry.getValue().cancel(true);
			  scheduledTasks.remove(entry.getKey());
		break;
		  }
		}
		
		
	}
	public void createJob(Check check) {
		ScheduledFuture<?> future=taskScheduler.schedule(new Runnable() {

			@Override
			public void run() {
				try {
					  Thread.currentThread().setName(check.getUrl());
					System.err.println("start----------------"+ new Date()+" "+Thread.currentThread().getId());
					checkStatusAndStoreInDatabase(check);
				}
				catch(Exception e){
					e.printStackTrace();
					
				}
			}
			
		},new Trigger() {
			@Override
			public Date nextExecutionTime(TriggerContext triggerContext) {
				System.err.println(check.getUrl());
			;
			long seconds=LocalDateTime.now().getSecond();
				System.err.println(seconds);
				 String cronExp =	seconds+" 0/"+check.getFrequency()+" * * * ?";
				System.out.println(cronExp);// Can be pulled from a db .
                 return new CronTrigger(cronExp).nextExecutionTime(triggerContext);
			}
			
		});
		 scheduledTasks.put(check.getName(), future);
		 System.out.println(future);
	}
	
	
	public void threadStatus() {

		Set<Thread> threads = Thread.getAllStackTraces().keySet();
		 
		for (Thread t : threads) {
		    String name = t.getName();
		    Thread.State state = t.getState();
		    int priority = t.getPriority();
		    String type = t.isDaemon() ? "Daemon" : "Normal";
		    System.out.printf("%-20s \t %s \t %d \t %s\n", name, state, priority, type);
		}
	}
}

