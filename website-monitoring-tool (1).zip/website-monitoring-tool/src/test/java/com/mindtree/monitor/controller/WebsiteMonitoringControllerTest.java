package com.mindtree.monitor.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.monitor.exception.InvalidCheckException;
import com.mindtree.monitor.model.Check;
import com.mindtree.monitor.service.WebsiteMonitoringService;
import com.mindtree.monitor.service.WebsiteMonitoringServiceImplementation;

import io.jsonwebtoken.lang.Assert;

@RunWith(SpringRunner.class)
@WebMvcTest(value= WebsiteMonitoringController.class)
public class WebsiteMonitoringControllerTest {
	@Autowired
	WebsiteMonitoringController controller;
	@MockBean
	WebsiteMonitoringServiceImplementation service;
    @Test
    public void createCheckTest() throws InvalidCheckException {
    	Check check=new Check();
    	check.setUrl("https://www.google.com");
		 Mockito.when(service.statusForSingleCheck(check)).thenReturn(null);
			assertEquals(controller.createCheck(check).getStatusCodeValue(),200);
			
			}
	 @Test
	 public void getAllCheckTest() {
		 Mockito.when(service.getAllCheck()).thenReturn(null);
			assertEquals(controller.getAllCheck().getBody(),null);
			
			}
	 @Test
	 public void deleteCheckTest() {
		 assertEquals(controller.deleteCheck(Mockito.any()).getBody(),"Successfully deleted");
			
			
			}
	@Test
	public void updateCheckTest() throws InvalidCheckException {
		 assertEquals(controller.updateCheck(Mockito.any()).getBody(),"Successfully updated");
			
			}
	 @Test
	 public void filterCheckByIntervalAndNameTest() {
		 Mockito.when(service.filterCheckByIntervalAndName(Mockito.any())).thenReturn(null);
			assertEquals(controller.filterCheckByIntervalAndName(Mockito.any()).getBody(),null);
			
			}
	 @Test
	 public void deactivateCheckTest() {
		
			assertEquals(controller.deactivateCheck(Mockito.any()).getStatusCodeValue(),200);
			
			}
@Test
public void activateCheckTest() {

	assertEquals(controller.activateCheck(Mockito.any()).getStatusCodeValue(),200);
	
	}

	 
}
