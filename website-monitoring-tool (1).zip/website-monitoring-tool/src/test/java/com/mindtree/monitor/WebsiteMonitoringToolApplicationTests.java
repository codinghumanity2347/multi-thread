package com.mindtree.monitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsiteMonitoringToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
