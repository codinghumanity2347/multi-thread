package com.mindtree.monitor.authentication;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.monitor.dto.LoginDTO;
import com.mindtree.monitor.exception.CustomerNotFoundException;
import com.mindtree.monitor.exception.UnauthorizedException;
import com.mindtree.monitor.service.WebsiteMonitoringServiceImplementation;



@RunWith(SpringRunner.class)
@WebMvcTest(value = JwtAuthenticationService.class)
public class JwtAuthenticationServiceTest {

	@Autowired
	JwtAuthenticationService jwtAuthenticationService;

	

	String email = "shreya@gmail.com";
	String password = "password";
	
	long id = 1L;

//	@Test
//	public void authenticateUser_invalidEmail() throws UnauthorizedException {
//		LoginDTO user = new LoginDTO();
//		user.setEmail("ample@gmail.com");
//		Assertions.assertThrows(CustomerNotFoundException.class, () -> {
//			jwtAuthenticationService.authenticateUser(user);
//		});
//
//	}
//
//	@Test
//	public void authenticateUser_invalidpassword() {
//		LoginDTO user = new LoginDTO();
//		user.setEmail(email);
//		user.setPassword("pass");
//		Assertions.assertThrows(UnauthorizedException.class, () -> {
//			jwtAuthenticationService.authenticateUser(user);
//		});
//
//	}
//
//	@Test
//	public void authenticateUser() throws UnauthorizedException {
//		LoginDTO user = new LoginDTO();
//		user.setEmail(email);
//		user.setPassword(password);
//		String jwt = jwtAuthenticationService.authenticateUser(user);
//		assertNotNull(jwt);
//	}

}
