package com.mindtree.monitor.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.mindtree.monitor.controller.JwtAuthenticationController;
import com.mindtree.monitor.exception.InvalidCheckException;
import com.mindtree.monitor.model.Check;
import com.mindtree.monitor.repository.WebsiteMonitoringRepository;
import com.mindtree.monitor.service.WebsiteMonitoringServiceImplementation;

@RunWith(SpringRunner.class)
@WebMvcTest(value = WebsiteMonitoringServiceImplementation.class)
public class WebsiteMonitoringServiceImplemtationTest {

	
	@Autowired
	WebsiteMonitoringServiceImplementation service;
	@MockBean
	WebsiteMonitoringRepository repository;
	String check="Google";
	@Test
	public void createCheckTest() throws InvalidCheckException {
		Check check=new Check();
    	check.setUrl("https://www.google.com");
		service.createCheck(check);
	}
	@Test
	public void createCheck_DeactivatedTest() throws InvalidCheckException {
		Check check=new Check();
    	check.setIsActive("d");
		service.createCheck(check);
	}
	@Test
	public void getAllCheckTest() {
		service.getAllCheck();
	}
	@Test
	public void filterCheckByIntervalAndNameTest() {
		Mockito.when(repository.findByNameContainingIgnoreCase(check)).thenReturn(null);
		service.filterCheckByIntervalAndName(check);
	}
	@Test
	public void filterCheckByIntervalAndName_FrequencyTest() {
		String check="10";
		Mockito.when(repository.findByFrequency(Long.parseLong(check))).thenReturn(null);
		assertEquals(service.filterCheckByIntervalAndName(check),null);
	}
	@Test
	public void deactivateCheckTest() {
		Mockito.when(repository.findById(check)).thenReturn(Optional.of(new Check()));
		service.deactivateCheck(check);
	}
@Test
public void activateCheckTest() {
	Mockito.when(repository.findById(check)).thenReturn(Optional.of(new Check()));
	service.activateCheck(check);
}
@Test
public void deleteCheckTest() {
	service.deleteCheck(Mockito.any());
	
}
//@Test
//public void updateStatusTest() {
//	List<Check> checklist=new ArrayList<>();
//	Check check=new Check();
//	check.setIsActive("d");
//	checklist.add(check);
//	Mockito.when(repository.findAll()).thenReturn(checklist );
//	service.updateStatus();
//}
@Test
public void updateCheckTest() throws InvalidCheckException {
	Check check=new Check();
	
	Mockito.when(repository.findById(Mockito.any())).thenReturn(Optional.of(new Check()));
service.updateCheck(check);
	
}
}
